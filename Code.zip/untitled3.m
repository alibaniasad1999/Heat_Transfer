b = flipdim(T_D0W, 2);
image(b)
axis equal
axis([0 200 0 400])
view([270 270])
