[row,col] = find(T_0W==min(min(T_0W)));
max(row)
min(row)
min(min(T_0W))
