b = flipdim(T_0W, 2);
image(b)
axis equal
axis([0 100 0 200])
view([270 270])